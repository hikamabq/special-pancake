<?php
$title='Home';
require_once 'view/header.php';
 ?>

<div class="main">
	<?php require_once 'view/menu.php'; ?>
	<div class="isi">
		<center><h1>SEKO-NOL v1.0 - 2018</h1></center>
	</div>
</div>
 
<?php 
require_once 'view/footer.php';
 ?>