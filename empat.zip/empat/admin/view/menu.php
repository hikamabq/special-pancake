<div class="menu-admin">
	<a href="index.php"><i class="fa fa-home"></i> Home</a>
	<a href="data_user.php"><i class="fa fa-user"></i> Data User</a>
	<a href="data_sekolah.php"><i class="fa fa-folder"></i> Data Sekolah</a>
	<a href="token.php">&#9776; Token</a>
	<a href="ta.php"><i class="fa fa-calendar"></i> Tahun Ajaran</a>
	<a href="forum.php"><i class="fa fa-group"></i> Forum</a>
</div>