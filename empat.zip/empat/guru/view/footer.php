<div class="footer-guru">
	Dibuat dengan <div style="display:inline-block; color:#eb3838;"><i class="fa fa-heart"></i></div> oleh Fantastic 4
</div>
</body>
</html>
